'use strict';

const SETTINGS_KEY = 'tabmind_settings';
const TAB_PREFIX = 'tabmind_tab_';
const ALARM_PREFIX = 'tabmind_checkin_';
const NOTIF_PREFIX = 'tabmind_notification_';

const DEFAULTS = {
  showPill: true,
  showTimer: true,
  opacity: 0.94,
  triggerMinutes: 30,
  notifications: true,
  pillPosition: null
};

const tabKey = id => `${TAB_PREFIX}${id}`;
const alarmName = id => `${ALARM_PREFIX}${id}`;

async function getSettings() {
  const data = await chrome.storage.local.get(SETTINGS_KEY);
  if (data[SETTINGS_KEY]) return { ...DEFAULTS, ...data[SETTINGS_KEY] };

  const legacy = await chrome.storage.local.get([
    'showPill', 'showTimer', 'opacity', 'triggerSeconds', 'notifications'
  ]);
  const settings = {
    showPill: legacy.showPill ?? DEFAULTS.showPill,
    showTimer: legacy.showTimer ?? DEFAULTS.showTimer,
    opacity: legacy.opacity ?? DEFAULTS.opacity,
    triggerMinutes: legacy.triggerSeconds != null
      ? Math.max(1, Math.round(Number(legacy.triggerSeconds) / 60))
      : DEFAULTS.triggerMinutes,
    notifications: legacy.notifications ?? DEFAULTS.notifications,
    pillPosition: DEFAULTS.pillPosition
  };
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  return settings;
}

async function setSettings(patch = {}) {
  const next = { ...(await getSettings()), ...patch };
  next.triggerMinutes = Math.max(1, Math.min(240, Math.round(Number(next.triggerMinutes) || 30)));
  next.opacity = Math.max(0.45, Math.min(1, Number(next.opacity) || 0.94));
  if (
    next.pillPosition &&
    (!Number.isFinite(next.pillPosition.x) || !Number.isFinite(next.pillPosition.y))
  ) {
    next.pillPosition = null;
  }
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return next;
}

async function getTabState(tabId) {
  const data = await chrome.storage.local.get(tabKey(tabId));
  return data[tabKey(tabId)] || null;
}

async function setTabState(tabId, patch) {
  const current = (await getTabState(tabId)) || {};
  const next = { ...current, ...patch };
  await chrome.storage.local.set({ [tabKey(tabId)]: next });
  return next;
}

function normalizeTabMetadata(tab) {
  return {
    tabTitle: typeof tab?.title === 'string' ? tab.title.slice(0, 160) : '',
    url: typeof tab?.url === 'string' ? tab.url : ''
  };
}

function getSiteLabel(state) {
  const rawUrl = typeof state?.url === 'string' ? state.url : '';
  if (rawUrl) {
    try {
      const parsed = new URL(rawUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return parsed.hostname.replace(/^www\./, '') || state.tabTitle || 'Current tab';
      }
      if (parsed.protocol === 'chrome-extension:') {
        return 'New tab';
      }
      if (parsed.protocol === 'chrome:' || parsed.protocol === 'edge:') {
        return parsed.hostname || 'Browser page';
      }
    } catch {}
  }

  return state.tabTitle || 'Current tab';
}

async function clearTab(tabId) {
  await chrome.storage.local.remove(tabKey(tabId));
  await chrome.alarms.clear(alarmName(tabId)).catch(() => false);
}

async function storeNotificationMeta(id, value) {
  await chrome.storage.session.set({ [id]: value }).catch(() => {});
}

async function readNotificationMeta(id) {
  const data = await chrome.storage.session.get(id).catch(() => ({}));
  return data[id] || null;
}

async function clearNotificationMeta(id) {
  await chrome.storage.session.remove(id).catch(() => {});
}

async function scheduleCheckin(tabId, minutes, createdAt = Date.now()) {
  const m = Math.max(1, Math.min(240, Math.round(Number(minutes) || 30)));
  await chrome.alarms.clear(alarmName(tabId)).catch(() => false);

  const dueAt = Number(createdAt) + m * 60_000;
  const remainingMs = dueAt - Date.now();
  const delayInMinutes = Math.max(0.01, remainingMs / 60_000);

  await chrome.alarms.create(alarmName(tabId), {
    delayInMinutes,
    periodInMinutes: m
  });
}

async function ensureTab(tabId) {
  let state = await getTabState(tabId);
  if (!state) {
    state = {
      createdAt: Date.now(),
      reason: null,
      checkins: 0,
      lastCheckinAt: 0,
      tabTitle: '',
      url: ''
    };
    await setTabState(tabId, state);
  }

  const alarm = await chrome.alarms.get(alarmName(tabId));
  if (!alarm) await scheduleCheckin(tabId, (await getSettings()).triggerMinutes, state.createdAt);
  return state;
}

async function syncTabMetadata(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    return await setTabState(tabId, normalizeTabMetadata(tab));
  } catch {
    return getTabState(tabId);
  }
}

async function reconcile() {
  const tabs = await chrome.tabs.query({});
  const openIds = new Set(tabs.map(t => t.id).filter(id => typeof id === 'number'));

  const data = await chrome.storage.local.get(null);
  const stale = Object.keys(data).filter(k =>
    k.startsWith(TAB_PREFIX) && !openIds.has(Number(k.slice(TAB_PREFIX.length)))
  );
  if (stale.length) await chrome.storage.local.remove(stale);

  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (!alarm.name.startsWith(ALARM_PREFIX)) continue;
    const id = Number(alarm.name.slice(ALARM_PREFIX.length));
    if (!openIds.has(id)) await chrome.alarms.clear(alarm.name);
  }

  for (const id of openIds) {
    try {
      await ensureTab(id);
    } catch (error) {
      console.warn('TabMind reconcile:', error);
    }
  }
}

function buildReminderMessage(state) {
  const reason = state.reason || 'No lockin reason';
  return `Lockin:- ${reason}`;
}

async function showReminderNotification(tabId, state) {
  const id = `${NOTIF_PREFIX}${tabId}_${Date.now()}`;
  await storeNotificationMeta(id, { tabId });
  await chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: `TabMind - ${getSiteLabel(state)}`,
    message: buildReminderMessage(state),
    priority: 2,
    requireInteraction: true,
    buttons: [
      { title: 'Keep Open' },
      { title: 'Close Tab' }
    ]
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  await getSettings();
  await reconcile();
});

chrome.runtime.onStartup.addListener(reconcile);

chrome.tabs.onCreated.addListener(async tab => {
  if (typeof tab.id !== 'number') return;
  const settings = await getSettings();
  const state = {
    createdAt: Date.now(),
    reason: null,
    checkins: 0,
    lastCheckinAt: 0,
    ...normalizeTabMetadata(tab)
  };
  await setTabState(tab.id, state);
  await scheduleCheckin(tab.id, settings.triggerMinutes, state.createdAt);
});

chrome.tabs.onRemoved.addListener(tabId => clearTab(tabId));

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!changeInfo.title && !changeInfo.url && changeInfo.status !== 'complete') return;
  await setTabState(tabId, normalizeTabMetadata(tab));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const tabId = sender.tab?.id ?? message?.tabId;

    switch (message?.type) {
      case 'GET_TAB_STATE': {
        if (typeof tabId !== 'number') return null;
        await ensureTab(tabId);
        const state = await syncTabMetadata(tabId);
        return { ...state, settings: await getSettings() };
      }

      case 'SET_REASON': {
        if (typeof tabId !== 'number') return { ok: false };
        const reason = String(message.reason || '').trim().slice(0, 120);
        const next = await setTabState(tabId, { reason: reason || null });
        return { ok: true, state: next };
      }

      case 'GET_POPUP_STATE': {
        if (typeof tabId !== 'number') return null;
        await ensureTab(tabId);
        return { state: await syncTabMetadata(tabId), settings: await getSettings() };
      }

      case 'UPDATE_SETTINGS': {
        const settings = await setSettings(message.settings || {});
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
          if (typeof tab.id !== 'number') continue;
          const state = await ensureTab(tab.id);
          await scheduleCheckin(tab.id, settings.triggerMinutes, state.createdAt);
          try {
            await chrome.tabs.sendMessage(tab.id, {
              type: 'SETTINGS_UPDATED', settings
            });
          } catch {}
        }
        return { ok: true, settings };
      }

      case 'CHECKIN_RESPONSE': {
        if (typeof tabId !== 'number') return { ok: false };
        const existing = await getTabState(tabId);
        const reason = String(message.reason || '').trim().slice(0, 120);
        const state = await setTabState(tabId, {
          reason: reason || (message.keepExisting ? existing?.reason || null : null),
          lastResponseAt: Date.now()
        });
        return { ok: true, state };
      }

      default:
        return null;
    }
  })().then(sendResponse).catch(error => {
    console.error('TabMind:', error);
    sendResponse({ ok: false, error: String(error) });
  });

  return true;
});

async function triggerCheckin(tabId) {
  try {
    await chrome.tabs.get(tabId);
  } catch {
    await clearTab(tabId);
    return;
  }

  await ensureTab(tabId);
  const state = await syncTabMetadata(tabId);
  const count = (state.checkins || 0) + 1;
  const nextState = await setTabState(tabId, { checkins: count, lastCheckinAt: Date.now() });

  const settings = await getSettings();
  if (settings.notifications) {
    await showReminderNotification(tabId, nextState);
  }
}

chrome.alarms.onAlarm.addListener(async alarm => {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return;
  const tabId = Number(alarm.name.slice(ALARM_PREFIX.length));
  if (!Number.isFinite(tabId)) return;
  await triggerCheckin(tabId);
});

chrome.notifications.onClicked.addListener(async id => {
  if (!id.startsWith(NOTIF_PREFIX)) return;
  const meta = await readNotificationMeta(id);
  const tabId = meta?.tabId;
  if (typeof tabId !== 'number') return;
  try {
    const tab = await chrome.tabs.get(tabId);
    await chrome.windows.update(tab.windowId, { focused: true });
    await chrome.tabs.update(tabId, { active: true });
  } catch {}
  await clearNotificationMeta(id);
});

chrome.notifications.onButtonClicked.addListener(async (id, buttonIndex) => {
  if (!id.startsWith(NOTIF_PREFIX)) return;
  const meta = await readNotificationMeta(id);
  const tabId = meta?.tabId;
  if (typeof tabId !== 'number') {
    await chrome.notifications.clear(id).catch(() => false);
    await clearNotificationMeta(id);
    return;
  }

  if (buttonIndex === 0) {
    await setTabState(tabId, { lastResponseAt: Date.now() });
  } else if (buttonIndex === 1) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {}
  }

  await chrome.notifications.clear(id).catch(() => false);
  await clearNotificationMeta(id);
});

chrome.notifications.onClosed.addListener(id => {
  if (id.startsWith(NOTIF_PREFIX)) clearNotificationMeta(id);
});
