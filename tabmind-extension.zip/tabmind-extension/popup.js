'use strict';
const $=id=>document.getElementById(id);
const DEFAULTS={showPill:true,showTimer:true,opacity:.94,triggerMinutes:30,notifications:true};
async function load(){
  const data=await chrome.storage.local.get('tabmind_settings');
  const s={...DEFAULTS,...(data.tabmind_settings||{})};
  $('showPill').checked=!!s.showPill;$('showTimer').checked=!!s.showTimer;$('notifications').checked=!!s.notifications;
  $('triggerMinutes').value=s.triggerMinutes;$('opacity').value=s.opacity;$('opacityValue').textContent=Math.round(s.opacity*100)+'%';
}
async function set(p){const r=await chrome.runtime.sendMessage({type:'UPDATE_SETTINGS',settings:p});$('status').textContent=r?.ok?'Saved':'Could not save';setTimeout(()=>{$('status').textContent=''},1200)}
$('showPill').onchange=()=>set({showPill:$('showPill').checked});
$('showTimer').onchange=()=>set({showTimer:$('showTimer').checked});
$('notifications').onchange=()=>set({notifications:$('notifications').checked});
$('triggerMinutes').onchange=()=>{let v=Math.round(Number($('triggerMinutes').value)||30);v=Math.max(1,Math.min(240,v));$('triggerMinutes').value=v;set({triggerMinutes:v})};
$('opacity').oninput=()=>{$('opacityValue').textContent=Math.round(Number($('opacity').value)*100)+'%';set({opacity:Number($('opacity').value)})};
$('openNewTab').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('newtab.html')});
load();
