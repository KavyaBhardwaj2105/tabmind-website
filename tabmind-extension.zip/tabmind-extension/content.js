(() => {
  'use strict';
  if (window.top !== window) return;
  if (window.__tabMindLoaded) return;
  window.__tabMindLoaded = true;

  const DEFAULTS = {
    showPill: true,
    showTimer: true,
    opacity: 0.94,
    triggerMinutes: 30,
    notifications: true,
    pillPosition: null
  };

  const FADE_DELAY_MS = 2800;

  let state = { createdAt: Date.now(), reason: null, checkins: 0 };
  let settings = { ...DEFAULTS };
  let root = null;
  let pill = null;
  let timerEl = null;
  let overlay = null;
  let tickHandle = null;
  let drag = null;
  let fadeHandle = null;
  let pointerMoved = false;

  const send = message => new Promise(resolve => {
    try {
      chrome.runtime.sendMessage(message, response => {
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    } catch {
      resolve(null);
    }
  });

  const format = total => {
    total = Math.max(0, Math.floor(total));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;

    if (hours) {
      return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }

    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  function ensureRoot() {
    if (!document.body) return null;
    if (!root || !root.isConnected) {
      root = document.createElement('div');
      root.id = '__tabmind_root__';
      document.body.appendChild(root);
    }
    return root;
  }

  function getBounds() {
    return { width: window.innerWidth, height: window.innerHeight };
  }

  function clampPosition(x, y, width, height) {
    const bounds = getBounds();
    return {
      x: Math.min(Math.max(12, x), Math.max(12, bounds.width - width - 12)),
      y: Math.min(Math.max(12, y), Math.max(12, bounds.height - height - 12))
    };
  }

  function applyPillPosition() {
    if (!pill) return;
    const rect = pill.getBoundingClientRect();
    const preferred = settings.pillPosition || { x: window.innerWidth - rect.width - 24, y: 18 };
    const next = clampPosition(preferred.x, preferred.y, rect.width, rect.height);
    pill.style.left = `${next.x}px`;
    pill.style.top = `${next.y}px`;
    pill.style.right = 'auto';
  }

  async function persistPillPosition(x, y) {
    if (!pill) return;
    const rect = pill.getBoundingClientRect();
    const next = clampPosition(x, y, rect.width, rect.height);
    settings = { ...settings, pillPosition: next };
    applyPillPosition();
    await send({ type: 'UPDATE_SETTINGS', settings: { pillPosition: next } });
  }

  function clearFadeTimer() {
    if (fadeHandle) {
      clearTimeout(fadeHandle);
      fadeHandle = null;
    }
  }

  function scheduleFade() {
    if (!pill) return;
    clearFadeTimer();
    pill.classList.remove('tm-pill--faded');
    fadeHandle = setTimeout(() => {
      if (pill && !drag && !overlay) pill.classList.add('tm-pill--faded');
    }, FADE_DELAY_MS);
  }

  function registerActivity() {
    scheduleFade();
  }

  function removeOverlay() {
    overlay?.remove();
    overlay = null;
    scheduleFade();
  }

  function bindDragEvents() {
    if (!pill) return;

    pill.addEventListener('pointerdown', event => {
      if (event.button !== 0 || !pill) return;

      const rect = pill.getBoundingClientRect();
      drag = {
        pointerId: event.pointerId,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top
      };
      pointerMoved = false;
      pill.classList.add('tm-pill--dragging');
      pill.classList.remove('tm-pill--faded');
      pill.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    });

    pill.addEventListener('pointermove', event => {
      if (!drag || drag.pointerId !== event.pointerId || !pill) return;

      pointerMoved = true;
      const rect = pill.getBoundingClientRect();
      const next = clampPosition(
        event.clientX - drag.offsetX,
        event.clientY - drag.offsetY,
        rect.width,
        rect.height
      );

      pill.style.left = `${next.x}px`;
      pill.style.top = `${next.y}px`;
      pill.style.right = 'auto';
    });

    const finishDrag = async event => {
      if (!drag || drag.pointerId !== event.pointerId || !pill) return;

      const rect = pill.getBoundingClientRect();
      drag = null;
      pill.classList.remove('tm-pill--dragging');
      pill.releasePointerCapture?.(event.pointerId);
      await persistPillPosition(rect.left, rect.top);

      if (!pointerMoved) {
        showPrompt(false);
      } else {
        scheduleFade();
      }
    };

    pill.addEventListener('pointerup', finishDrag);
    pill.addEventListener('pointercancel', finishDrag);
    pill.addEventListener('mouseenter', () => pill?.classList.remove('tm-pill--faded'));
    pill.addEventListener('mouseleave', scheduleFade);
  }

  function render() {
    const currentRoot = ensureRoot();
    if (!currentRoot) return;

    currentRoot.querySelector('.tm-pill')?.remove();
    if (!settings.showPill || !settings.showTimer) {
      timerEl = null;
      pill = null;
      return;
    }

    pill = document.createElement('button');
    pill.className = 'tm-pill';
    pill.type = 'button';
    pill.title = state.reason || 'Set lock-in reason';
    pill.style.setProperty('--tm-opacity', String(settings.opacity));

    const glow = document.createElement('span');
    glow.className = 'tm-dot';

    const timer = document.createElement('span');
    timer.className = 'tm-timer';
    timer.textContent = format((Date.now() - state.createdAt) / 1000);

    pill.append(glow, timer);
    currentRoot.appendChild(pill);
    timerEl = timer;

    bindDragEvents();
    requestAnimationFrame(() => {
      applyPillPosition();
      scheduleFade();
    });
  }

  function updateTimer() {
    if (timerEl) {
      timerEl.textContent = format((Date.now() - state.createdAt) / 1000);
    }
  }

  function showPrompt(triggered) {
    if (!document.body || document.visibilityState === 'hidden' || overlay) return false;
    const currentRoot = ensureRoot();
    if (!currentRoot) return false;

    clearFadeTimer();
    overlay = document.createElement('div');
    overlay.className = 'tm-overlay';

    const card = document.createElement('div');
    card.className = 'tm-card';
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-modal', 'true');

    const kicker = document.createElement('div');
    kicker.className = 'tm-kicker';
    kicker.textContent = triggered ? 'Stale Tab Check' : 'Lock-In Reason';

    const title = document.createElement('h2');
    title.className = 'tm-title';
    title.textContent = triggered ? 'Does this tab still matter?' : 'Why is this tab open?';

    const sub = document.createElement('p');
    sub.className = 'tm-sub';
    sub.textContent = triggered
      ? 'Update the reason if you still need this tab. If not, close it and move on.'
      : 'Give the tab a short reason so future-you knows whether it should still stay open.';

    const input = document.createElement('input');
    input.className = 'tm-field';
    input.maxLength = 120;
    input.placeholder = 'Reply to recruiter email';
    input.value = state.reason || '';

    const actions = document.createElement('div');
    actions.className = 'tm-actions';

    const skip = document.createElement('button');
    skip.className = 'tm-btn';
    skip.textContent = 'Not now';
    skip.type = 'button';

    const save = document.createElement('button');
    save.className = 'tm-btn primary';
    save.textContent = 'Save reason';
    save.type = 'button';

    actions.append(skip, save);

    const hint = document.createElement('div');
    hint.className = 'tm-hint';
    hint.textContent = 'Click outside, press Esc, or save when you are done.';

    card.append(kicker, title, sub, input, actions, hint);
    overlay.appendChild(card);
    currentRoot.appendChild(overlay);

    const close = () => removeOverlay();
    const saveIt = async () => {
      const clean = input.value.trim();
      if (!clean) {
        input.focus();
        return;
      }

      const result = await send({ type: 'SET_REASON', reason: clean });
      if (result?.ok) {
        state = result.state;
        render();
        close();
      }
    };

    save.onclick = saveIt;
    skip.onclick = close;
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        saveIt();
      } else if (event.key === 'Escape') {
        close();
      }
    });
    overlay.addEventListener('click', event => {
      if (event.target === overlay) close();
    });

    setTimeout(() => input.focus(), 20);
    return true;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'SETTINGS_UPDATED') {
      settings = { ...settings, ...message.settings };
      render();
      sendResponse?.({ ok: true });
      return;
    }

    if (message?.type === 'TRIGGER_CHECKIN') {
      sendResponse?.({ shown: false });
      return true;
    }
  });

  async function init() {
    if (!document.body || location.protocol === 'chrome-extension:') return;
    const result = await send({ type: 'GET_TAB_STATE' });
    if (!result) return;

    state = { ...state, ...result };
    settings = { ...DEFAULTS, ...(result.settings || {}) };
    render();
    clearInterval(tickHandle);
    tickHandle = setInterval(updateTimer, 1000);
  }

  window.addEventListener('resize', applyPillPosition);
  window.addEventListener('mousemove', registerActivity, { passive: true });
  window.addEventListener('keydown', registerActivity);
  window.addEventListener('scroll', registerActivity, { passive: true });
  window.addEventListener('click', registerActivity, { passive: true });
  window.addEventListener('pagehide', () => {
    clearInterval(tickHandle);
    clearFadeTimer();
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
