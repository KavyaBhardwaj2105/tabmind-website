'use strict';
const params=new URLSearchParams(location.search);const tabId=Number(params.get('tabId'));
const input=document.getElementById('reason');const save=document.getElementById('save');const skip=document.getElementById('skip');
async function send(message){return new Promise(resolve=>{try{chrome.runtime.sendMessage(message,r=>{void chrome.runtime.lastError;resolve(r)})}catch{resolve(null)}})}
async function init(){if(!Number.isFinite(tabId))return;const r=await send({type:'GET_POPUP_STATE',tabId});if(r?.state?.reason)input.value=r.state.reason;input.focus();input.select()}
async function finish(saveIt){const reason=input.value.trim();if(saveIt&&!reason){input.focus();return}await send({type:'CHECKIN_RESPONSE',tabId,reason,keepExisting:!saveIt});window.close()}
save.onclick=()=>finish(true);skip.onclick=()=>finish(false);input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();finish(true)}if(e.key==='Escape'){e.preventDefault();finish(false)}};init();
