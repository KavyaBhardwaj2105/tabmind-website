const input = document.getElementById('reason');
const main = document.querySelector('main');

function escapeHtml(value) {
  return value.replace(/[&<>"]/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;'
  }[char]));
}

function renderState({ eyebrow, title, body, reason, muted }) {
  main.innerHTML = `
    <section class="result-card">
      <p class="result-eyebrow">${eyebrow}</p>
      <h2 class="result-title">${title}</h2>
      <p class="result-body">${body}</p>
      ${reason ? `<div class="result-reason">${escapeHtml(reason)}</div>` : ''}
      <p class="result-muted">${muted}</p>
      <div class="result-actions">
        <button id="reset" type="button">Set another reason</button>
      </div>
    </section>
  `;

  document.getElementById('reset').onclick = () => window.location.reload();
}

async function save() {
  const reason = input.value.trim().slice(0, 120);
  if (!reason) return input.focus();

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tabId = tabs[0]?.id;
  await chrome.runtime.sendMessage({ type: 'SET_REASON', tabId, reason });

  renderState({
    eyebrow: 'Reason saved',
    title: 'Locked in.',
    body: 'Your tab now carries a clear job, so drifting is easier to catch later.',
    reason,
    muted: 'Open any site and the floating card will keep it visible.'
  });
}

document.getElementById('save').onclick = save;
document.getElementById('skip').onclick = () => {
  renderState({
    eyebrow: 'Skipped',
    title: 'No reason set.',
    body: 'You can still add a lock-in reason later from the floating card.',
    muted: 'Nothing was saved for this new tab.'
  });
};

input.addEventListener('keydown', event => {
  if (event.key === 'Enter') save();
  if (event.key === 'Escape') document.getElementById('skip').click();
});
