(() => {
  'use strict';
  if (window.top !== window) return;
  if (window.__tabMindLoaded) return;
  window.__tabMindLoaded = true;

  const DEFAULTS = { showPill:true, showTimer:true, opacity:.94, triggerMinutes:30, notifications:true };
  let state = { createdAt: Date.now(), reason:null, checkins:0 };
  let settings = {...DEFAULTS};
  let root = null, timerEl = null, overlay = null;
  let tickHandle = null;

  const send = (message) => new Promise(resolve => {
    try {
      chrome.runtime.sendMessage(message, response => {
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    } catch { resolve(null); }
  });

  const format = total => {
    total = Math.max(0, Math.floor(total));
    const h = Math.floor(total/3600), m = Math.floor((total%3600)/60), s = total%60;
    return h ? `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` :
      `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  };

  function ensureRoot() {
    if (!document.body) return null;
    if (!root || !root.isConnected) {
      root = document.createElement('div');
      root.id = '__tabmind_root__';
      document.body.appendChild(root);
    }
    return root;
  }

  function render() {
    const r = ensureRoot();
    if (!r) return;
    r.querySelector('.tm-pill')?.remove();
    if (!settings.showPill) { timerEl=null; return; }

    const pill = document.createElement('div');
    pill.className='tm-pill';
    pill.style.setProperty('--tm-opacity', String(settings.opacity));
    const dot=document.createElement('span'); dot.className='tm-dot';
    const text=document.createElement('span'); text.className='tm-text'; text.textContent=state.reason || 'Set your intention';
    const timer=document.createElement('span'); timer.className='tm-timer'; timer.textContent=format((Date.now()-state.createdAt)/1000);
    const edit=document.createElement('button'); edit.className='tm-edit'; edit.type='button'; edit.title='Edit intention'; edit.textContent='✎';
    pill.append(dot,text,timer,edit); r.appendChild(pill); timerEl=timer;
    timer.style.display=settings.showTimer?'':'none';
    text.onclick=state.reason?editReason:()=>showPrompt(false);
    edit.onclick=()=>showPrompt(false);
  }

  function updateTimer() {
    if (timerEl) timerEl.textContent=format((Date.now()-state.createdAt)/1000);
  }

  function removeOverlay(){ overlay?.remove(); overlay=null; }

  function showPrompt(triggered) {
    if (!document.body || document.visibilityState === 'hidden' || overlay) return false;
    const r=ensureRoot(); if(!r) return false;

    overlay=document.createElement('div'); overlay.className='tm-overlay';
    const card=document.createElement('div'); card.className='tm-card'; card.setAttribute('role','dialog'); card.setAttribute('aria-modal','true');

    const kicker=document.createElement('div'); kicker.className='tm-kicker';
    kicker.textContent=triggered ? 'TABMIND · 30 MINUTE CHECK-IN' : 'TABMIND · INTENTION';
    const title=document.createElement('h2'); title.className='tm-title'; title.textContent=triggered ? 'Still on purpose?' : 'Why did you open this tab?';
    const sub=document.createElement('p'); sub.className='tm-sub';
    sub.textContent=triggered ? 'You have been on this tab for 30 minutes. Take a second to check whether it still deserves your attention.' : 'Set a small intention and keep it visible while you browse.';
    const input=document.createElement('input'); input.className='tm-field'; input.maxLength=120; input.placeholder='e.g. Research Ladakh trip…'; input.value=state.reason || '';
    const actions=document.createElement('div'); actions.className='tm-actions';
    const skip=document.createElement('button'); skip.className='tm-btn'; skip.textContent='Not now'; skip.type='button';
    const save=document.createElement('button'); save.className='tm-btn primary'; save.textContent='Remember it →'; save.type='button';
    actions.append(skip,save);
    const hint=document.createElement('div'); hint.className='tm-hint'; hint.textContent='Enter to save · Esc to dismiss';
    if(triggered){ const note=document.createElement('div'); note.className='tm-trigger'; note.textContent='Automatic check-in after 30 minutes.'; card.append(kicker,title,sub,input,actions,hint,note); }
    else card.append(kicker,title,sub,input,actions,hint);
    overlay.appendChild(card); r.appendChild(overlay);

    const close=()=>removeOverlay();
    const saveIt=async()=> {
      const clean=input.value.trim();
      if(!clean){ input.focus(); return; }
      const result=await send({type:'SET_REASON',reason:clean});
      if(result?.ok){ state=result.state; render(); close(); }
    };
    save.onclick=saveIt; skip.onclick=close;
    input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();saveIt()} else if(e.key==='Escape'){close()}});
    overlay.addEventListener('click',e=>{if(e.target===overlay)close()});
    setTimeout(()=>input.focus(),20);
    return true;
  }

  async function editReason(){ showPrompt(false); }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if(message?.type==='SETTINGS_UPDATED'){
      settings={...settings,...message.settings}; render(); sendResponse?.({ok:true}); return;
    }
    if(message?.type==='TRIGGER_CHECKIN'){
      // The background service worker opens the guaranteed real extension popup.
      // Keep this listener as a compatibility hook; no duplicate overlay is created.
      sendResponse?.({shown:false});
      return true;
    }
  });

  async function init(){
    if(!document.body || location.protocol==='chrome-extension:') return;
    const result=await send({type:'GET_TAB_STATE'});
    if(!result) return;
    state={...state,...result};
    settings={...DEFAULTS,...(result.settings||{})};
    render();
    clearInterval(tickHandle);
    tickHandle=setInterval(updateTimer,1000);
  }

  window.addEventListener('pagehide',()=>clearInterval(tickHandle));
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})();