'use strict';

(function () {
  // Guard against double-injection (e.g. extension reload while page is open).
  if (window.__tabmindInjected) return;
  window.__tabmindInjected = true;

  const DEFAULT_SETTINGS = {
    showReasonPill: true,
    showTimerPill: true,
    reasonPillOpacity: 0.95,
    reminderIntervalMinutes: 30
  };

  const state = {
    reason: null, // plain string or null
    settings: DEFAULT_SETTINGS,
    tabCreatedAt: Date.now(),
    editing: false,
    timerHandle: null
  };

  let reasonPillEl = null;
  let reasonTextEl = null;
  let timerPillEl = null;
  let timerTextEl = null;

  /**
   * Wraps chrome.runtime.sendMessage so it NEVER throws and never leaves an
   * unhandled promise rejection — e.g. when the page has navigated away from
   * the message target, or the extension was just reloaded/updated and this
   * content script is now orphaned ("Extension context invalidated").
   */
  function safeSendMessage(message) {
    return new Promise((resolve) => {
      try {
        if (!chrome?.runtime?.id) {
          resolve(null);
          return;
        }
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(response);
        });
      } catch (err) {
        resolve(null);
      }
    });
  }

  // Escapes user-provided text before it ever touches innerHTML.
  function escapeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function formatElapsed(ms) {
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const mm = String(minutes).padStart(2, '0');
    const ss = String(seconds).padStart(2, '0');
    return hours > 0 ? `${hours}:${mm}:${ss}` : `${mm}:${ss}`;
  }

  function buildPills() {
    reasonPillEl = document.createElement('div');
    reasonPillEl.className = 'tabmind-pill tabmind-reason-pill';

    reasonTextEl = document.createElement('span');
    reasonTextEl.className = 'tabmind-reason-text';
    reasonTextEl.tabIndex = 0;
    reasonTextEl.addEventListener('click', beginEditReason);
    reasonTextEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        beginEditReason();
      }
    });
    reasonPillEl.appendChild(reasonTextEl);

    timerPillEl = document.createElement('div');
    timerPillEl.className = 'tabmind-pill tabmind-timer-pill';
    timerTextEl = document.createElement('span');
    timerTextEl.className = 'tabmind-timer-text';
    timerTextEl.textContent = '00:00';
    timerPillEl.appendChild(timerTextEl);

    document.documentElement.appendChild(reasonPillEl);
    document.documentElement.appendChild(timerPillEl);

    renderReasonPill();
    applySettings();
  }

  function renderReasonPill() {
    if (!reasonTextEl || state.editing) return;
    const label = state.reason ? state.reason : 'No reason set — click to add';
    const icon = state.reason ? '\u270E' : '+';
    // The reason text is user-provided, so it is escaped before insertion;
    // the surrounding markup (the icon span) is static and trusted.
    reasonTextEl.innerHTML = `${escapeHTML(label)} <span class="tabmind-edit-icon">${icon}</span>`;
    reasonPillEl.classList.toggle('tabmind-reason-empty', !state.reason);
  }

  function beginEditReason() {
    if (state.editing) return;
    state.editing = true;

    reasonPillEl.innerHTML = '';
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'tabmind-reason-input';
    input.maxLength = 300;
    input.value = state.reason || '';
    input.placeholder = 'Why did you open this tab?';
    reasonPillEl.appendChild(input);
    input.focus();
    input.select();

    let settled = false;
    const finishEditing = async (commit) => {
      if (settled) return;
      settled = true;
      state.editing = false;

      if (commit) {
        const value = input.value.trim();
        if (value && value !== state.reason) {
          const resp = await safeSendMessage({ type: 'UPDATE_REASON', reason: value });
          if (resp && resp.ok) state.reason = value;
        }
      }

      reasonPillEl.innerHTML = '';
      reasonPillEl.appendChild(reasonTextEl);
      renderReasonPill();
    };

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        finishEditing(true);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        finishEditing(false);
      }
    });
    input.addEventListener('blur', () => finishEditing(true));
  }

  function startTimer() {
    if (state.timerHandle) clearInterval(state.timerHandle);
    const tick = () => {
      if (!timerTextEl) return;
      timerTextEl.textContent = formatElapsed(Date.now() - state.tabCreatedAt);
    };
    tick();
    // This interval lives only as long as the page (this content script
    // instance), so it's safe here — unlike the service worker, this
    // context isn't expected to persist or be revived by the OS.
    state.timerHandle = setInterval(tick, 1000);
  }

  function applySettings() {
    if (!reasonPillEl || !timerPillEl) return;
    reasonPillEl.classList.toggle('tabmind-hidden', !state.settings.showReasonPill);
    timerPillEl.classList.toggle('tabmind-hidden', !state.settings.showTimerPill);
    // A direct CSSOM property assignment (not a style="" string or a
    // <style> tag), so it isn't blocked by strict style-src CSPs.
    reasonPillEl.style.opacity = String(state.settings.reasonPillOpacity ?? 0.95);
  }

  function showModal() {
    const overlay = document.createElement('div');
    overlay.className = 'tabmind-modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'tabmind-modal';

    const title = document.createElement('p');
    title.className = 'tabmind-modal-title';
    title.textContent = 'Why did you open this tab?';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'tabmind-modal-input';
    input.maxLength = 300;
    input.placeholder = 'e.g. Research flight prices';

    const actions = document.createElement('div');
    actions.className = 'tabmind-modal-actions';

    const skipBtn = document.createElement('button');
    skipBtn.type = 'button';
    skipBtn.className = 'tabmind-btn tabmind-btn-skip';
    skipBtn.textContent = 'Skip';

    const saveBtn = document.createElement('button');
    saveBtn.type = 'button';
    saveBtn.className = 'tabmind-btn tabmind-btn-save';
    saveBtn.textContent = 'Save';

    actions.appendChild(skipBtn);
    actions.appendChild(saveBtn);
    modal.appendChild(title);
    modal.appendChild(input);
    modal.appendChild(actions);
    overlay.appendChild(modal);
    document.documentElement.appendChild(overlay);

    input.focus();

    let closed = false;
    const closeModal = () => {
      if (closed) return;
      closed = true;
      overlay.remove();
    };

    const doSave = async () => {
      const value = input.value.trim();
      if (!value) {
        await doSkip();
        return;
      }
      const resp = await safeSendMessage({ type: 'SAVE_REASON', reason: value });
      if (resp && resp.ok) state.reason = value;
      renderReasonPill();
      closeModal();
    };

    const doSkip = async () => {
      await safeSendMessage({ type: 'SKIP_REASON' });
      renderReasonPill();
      closeModal();
    };

    saveBtn.addEventListener('click', doSave);
    skipBtn.addEventListener('click', doSkip);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        doSave();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        doSkip();
      }
    });
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'SETTINGS_UPDATED') {
      state.settings = { ...state.settings, ...message.settings };
      applySettings();
    }
    // No sendResponse needed; returning undefined (falsy) closes the channel.
  });

  function init() {
    safeSendMessage({ type: 'GET_TAB_STATE' }).then((resp) => {
      if (!resp) return; // background unreachable; skip UI rather than error
      state.reason = resp.reason ? resp.reason.reason : null;
      state.settings = { ...DEFAULT_SETTINGS, ...(resp.settings || {}) };
      state.tabCreatedAt = resp.tabCreatedAt || Date.now();

      buildPills();
      startTimer();
      if (resp.needsModal) showModal();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
