'use strict';

(function () {
  const els = {};

  function safeSendMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(response);
        });
      } catch (err) {
        resolve(null);
      }
    });
  }

  function setStatus(text) {
    els.status.textContent = text;
    if (text) {
      setTimeout(() => {
        if (els.status.textContent === text) els.status.textContent = '';
      }, 1500);
    }
  }

  async function getActiveTabId() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0]?.id ?? null;
  }

  async function pushSettingsPatch(patch) {
    const resp = await safeSendMessage({ type: 'UPDATE_SETTINGS', settings: patch });
    if (resp && resp.ok) {
      setStatus('Saved');
    } else {
      setStatus('Could not save — try reloading the page');
    }
  }

  async function init() {
    els.currentReason = document.getElementById('tm-current-reason');
    els.toggleReason = document.getElementById('tm-toggle-reason');
    els.toggleTimer = document.getElementById('tm-toggle-timer');
    els.opacity = document.getElementById('tm-opacity');
    els.interval = document.getElementById('tm-interval');
    els.status = document.getElementById('tm-status');

    const tabId = await getActiveTabId();
    if (tabId === null) {
      els.currentReason.textContent = 'No active tab found.';
      return;
    }

    const state = await safeSendMessage({ type: 'GET_POPUP_STATE', tabId });
    if (!state) {
      els.currentReason.textContent = 'TabMind is unavailable on this page.';
      disableControls();
      return;
    }

    els.currentReason.textContent = state.reason
      ? state.reason.reason
      : 'No reason saved for this tab yet.';

    const settings = state.settings;
    els.toggleReason.checked = !!settings.showReasonPill;
    els.toggleTimer.checked = !!settings.showTimerPill;
    els.opacity.value = settings.reasonPillOpacity;
    els.interval.value = settings.reminderIntervalMinutes;

    els.toggleReason.addEventListener('change', () => {
      pushSettingsPatch({ showReasonPill: els.toggleReason.checked });
    });

    els.toggleTimer.addEventListener('change', () => {
      pushSettingsPatch({ showTimerPill: els.toggleTimer.checked });
    });

    els.opacity.addEventListener('input', () => {
      pushSettingsPatch({ reasonPillOpacity: Number(els.opacity.value) });
    });

    els.interval.addEventListener('change', () => {
      let value = Math.round(Number(els.interval.value));
      if (!Number.isFinite(value) || value < 1) value = 1;
      if (value > 240) value = 240;
      els.interval.value = value;
      pushSettingsPatch({ reminderIntervalMinutes: value });
    });
  }

  function disableControls() {
    [els.toggleReason, els.toggleTimer, els.opacity, els.interval].forEach((el) => {
      if (el) el.disabled = true;
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
