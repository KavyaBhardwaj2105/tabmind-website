'use strict';

/**
 * TabMind background service worker.
 *
 * All persistent state lives in chrome.storage.local, keyed by tab ID:
 *   tabmind_reason_<tabId> -> { reason, timestamp, tabCreatedAt }
 *   tabmind_meta_<tabId>   -> { createdAt, asked }
 *   tabmind_settings       -> { showReasonPill, showTimerPill, reasonPillOpacity, reminderIntervalMinutes }
 *
 * Reminder notifications are scheduled with chrome.alarms (not setInterval),
 * so they keep firing even if this service worker is unloaded and later
 * woken back up by the alarm event.
 */

const SETTINGS_KEY = 'tabmind_settings';
const DEFAULT_SETTINGS = {
  showReasonPill: true,
  showTimerPill: true,
  reasonPillOpacity: 0.95,
  reminderIntervalMinutes: 30
};

const REASON_PREFIX = 'tabmind_reason_';
const META_PREFIX = 'tabmind_meta_';
const ALARM_PREFIX = 'tabmind_reminder_';

function reasonKey(tabId) {
  return `${REASON_PREFIX}${tabId}`;
}
function metaKey(tabId) {
  return `${META_PREFIX}${tabId}`;
}
function alarmName(tabId) {
  return `${ALARM_PREFIX}${tabId}`;
}
function tabIdFromAlarmName(name) {
  const n = Number(name.slice(ALARM_PREFIX.length));
  return Number.isFinite(n) ? n : null;
}

async function getSettings() {
  const data = await chrome.storage.local.get(SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...(data[SETTINGS_KEY] || {}) };
}

async function saveSettingsPatch(patch) {
  const current = await getSettings();
  const next = { ...current, ...patch };
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return next;
}

async function getMeta(tabId) {
  const data = await chrome.storage.local.get(metaKey(tabId));
  return data[metaKey(tabId)] || null;
}

async function setMeta(tabId, meta) {
  await chrome.storage.local.set({ [metaKey(tabId)]: meta });
}

async function getReason(tabId) {
  const data = await chrome.storage.local.get(reasonKey(tabId));
  return data[reasonKey(tabId)] || null;
}

async function setReason(tabId, reasonText, tabCreatedAt) {
  const record = {
    reason: reasonText,
    timestamp: Date.now(),
    tabCreatedAt
  };
  await chrome.storage.local.set({ [reasonKey(tabId)]: record });
  return record;
}

async function clearTabData(tabId) {
  await chrome.storage.local.remove([reasonKey(tabId), metaKey(tabId)]);
  try {
    await chrome.alarms.clear(alarmName(tabId));
  } catch (e) {
    /* no-op: alarm may not have existed */
  }
}

async function scheduleReminder(tabId, periodInMinutes) {
  const period = Math.max(1, Number(periodInMinutes) || DEFAULT_SETTINGS.reminderIntervalMinutes);
  await chrome.alarms.create(alarmName(tabId), { periodInMinutes: period });
}

/**
 * Chrome recycles tab IDs after a tab closes. If this service worker ever
 * misses an onRemoved event (e.g. it was asleep and woke up later, or the
 * browser restarted), storage could still hold data belonging to a tab ID
 * that has since been reassigned to a totally unrelated new tab. This sweep
 * removes any reason/meta/alarm whose tab ID isn't currently open.
 */
async function reconcileWithOpenTabs() {
  const [openTabs, storedItems] = await Promise.all([
    chrome.tabs.query({}),
    chrome.storage.local.get(null)
  ]);
  const openIds = new Set(openTabs.map((t) => t.id));

  const toRemove = [];
  for (const key of Object.keys(storedItems)) {
    if (key.startsWith(REASON_PREFIX)) {
      const id = Number(key.slice(REASON_PREFIX.length));
      if (!openIds.has(id)) toRemove.push(key);
    } else if (key.startsWith(META_PREFIX)) {
      const id = Number(key.slice(META_PREFIX.length));
      if (!openIds.has(id)) toRemove.push(key);
    }
  }
  if (toRemove.length) await chrome.storage.local.remove(toRemove);

  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (!alarm.name.startsWith(ALARM_PREFIX)) continue;
    const id = tabIdFromAlarmName(alarm.name);
    if (id === null || !openIds.has(id)) {
      await chrome.alarms.clear(alarm.name);
    }
  }
}

chrome.runtime.onInstalled.addListener(() => {
  saveSettingsPatch({});
  reconcileWithOpenTabs();
});

chrome.runtime.onStartup.addListener(() => {
  reconcileWithOpenTabs();
});

chrome.tabs.onCreated.addListener(async (tab) => {
  // Defensive cleanup: a brand-new tab must never inherit a stale reason
  // from a previously closed tab that happened to get the same numeric ID.
  await clearTabData(tab.id);
  await setMeta(tab.id, { createdAt: Date.now(), asked: false });
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await clearTabData(tabId);
});

// --- Messaging -------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((err) => {
      console.error('TabMind background error:', err);
      sendResponse(null);
    });
  return true; // keep the message channel open for the async response
});

async function handleMessage(message, sender) {
  switch (message?.type) {
    case 'GET_TAB_STATE': {
      const tabId = sender.tab?.id;
      if (tabId === undefined) return null;

      let meta = await getMeta(tabId);
      if (!meta) {
        meta = { createdAt: Date.now(), asked: false };
        await setMeta(tabId, meta);
      }

      const reason = await getReason(tabId);
      const settings = await getSettings();
      const needsModal = !reason && !meta.asked;

      if (needsModal) {
        meta.asked = true;
        await setMeta(tabId, meta);
      }

      return { reason, settings, tabCreatedAt: meta.createdAt, needsModal };
    }

    case 'SAVE_REASON':
    case 'UPDATE_REASON': {
      const tabId = sender.tab?.id;
      if (tabId === undefined) return { ok: false };

      const text = String(message.reason || '').trim().slice(0, 300);
      if (!text) return { ok: false };

      const meta = (await getMeta(tabId)) || { createdAt: Date.now(), asked: true };
      const record = await setReason(tabId, text, meta.createdAt);
      const settings = await getSettings();
      await scheduleReminder(tabId, settings.reminderIntervalMinutes);

      return { ok: true, record };
    }

    case 'SKIP_REASON': {
      const tabId = sender.tab?.id;
      if (tabId === undefined) return { ok: false };
      const meta = (await getMeta(tabId)) || { createdAt: Date.now(), asked: true };
      meta.asked = true;
      await setMeta(tabId, meta);
      return { ok: true };
    }

    case 'GET_POPUP_STATE': {
      const tabId = message.tabId;
      if (typeof tabId !== 'number') return null;
      const reason = await getReason(tabId);
      const meta = await getMeta(tabId);
      const settings = await getSettings();
      return { reason, settings, tabCreatedAt: meta?.createdAt || null };
    }

    case 'UPDATE_SETTINGS': {
      const next = await saveSettingsPatch(message.settings || {});

      // If the reminder cadence changed, re-arm every active alarm with the
      // new period instead of waiting for the old one to fire first.
      if (Object.prototype.hasOwnProperty.call(message.settings || {}, 'reminderIntervalMinutes')) {
        const items = await chrome.storage.local.get(null);
        const updates = [];
        for (const key of Object.keys(items)) {
          if (key.startsWith(REASON_PREFIX)) {
            const id = Number(key.slice(REASON_PREFIX.length));
            updates.push(scheduleReminder(id, next.reminderIntervalMinutes));
          }
        }
        await Promise.all(updates);
      }

      await broadcastSettings(next);
      return { ok: true, settings: next };
    }

    default:
      return null;
  }
}

async function broadcastSettings(settings) {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.id === undefined) continue;
    try {
      chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_UPDATED', settings }, () => {
        // Tabs without our content script (chrome://, the Web Store, etc.)
        // will report "no receiving end" here — that's expected, swallow it.
        void chrome.runtime.lastError;
      });
    } catch (e) {
      /* no-op */
    }
  }
}

// --- Reminders ---------------------------------------------------------

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return;
  const tabId = tabIdFromAlarmName(alarm.name);
  if (tabId === null) return;

  const reason = await getReason(tabId);
  if (!reason) {
    await chrome.alarms.clear(alarm.name);
    return;
  }

  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab) throw new Error('tab no longer exists');
  } catch (e) {
    await clearTabData(tabId);
    return;
  }

  chrome.notifications.create(`tabmind_notif_${tabId}_${Date.now()}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'TabMind reminder',
    message: reason.reason,
    priority: 0
  });
});
